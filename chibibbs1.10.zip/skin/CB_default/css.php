<style type="text/css">
.picDiv{float:left;}
.margin0{margin:0;}
.marginTop5{margin-top:5px;}
.left{float:left;}
#lightbox {
position:absolute;
top:0; 
left:0; 
min-width:100%; 
text-align:center;
}
#lightbox p {
color:#fff; 
margin-right:20px; 
font-size:12px; 
}
#lightbox img {
padding:20px;
background:url("./skin/<?=$bbs->skin?>/images/overlay.png") repeat;
box-shadow:0 0 25px #111;
-webkit-box-shadow:0 0 25px #111;
-moz-box-shadow:0 0 25px #111;
max-width:100%;
}
.comment{font-size:12px !important;}
#replyForm{margin-bottom:20px;display:none;}
ul.comment, blockquote{margin-bottom:5px;}
.adminpanel{position:fixed;right:5px;top:40%;}
.loadpic , #loadForm , .video{display:none;}
textarea{font-size:12px;}
.well {word-wrap:break-word;word-break:break-all;}
</style>